"""Build data/player_games.csv from the Hugging Face data set cbratkovics/nba-game-logs.

Run once from the repository root:  python scripts/build_data.py
Needs:  pip install -r requirements.txt   (internet connection required)
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from datasets import load_dataset

OUT = Path(__file__).resolve().parent.parent / "data"

raw = load_dataset("cbratkovics/nba-game-logs", split="train").to_pandas()
print(f"Downloaded {len(raw):,} rows, columns: {list(raw.columns)}")

df = raw.rename(columns={"game_date": "date", "player_name": "player", "minutes": "min"})
df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
df["loc"] = np.where(df["home"], "H", "A")

# The source has no win/loss column. A team won if its players scored more total
# points than the opponent's players. Only games with exactly two teams are used.
tp = df.groupby(["game_id", "team"], as_index=False)["pts"].sum()
two = tp.groupby("game_id")["team"].transform("size") == 2
tp = tp[two]
pair = tp.merge(tp, on="game_id", suffixes=("", "_opp"))
pair = pair[pair["team"] != pair["team_opp"]]
pair["result"] = np.where(pair["pts"] > pair["pts_opp"], "W", "L")
df = df.merge(pair[["game_id", "team", "result"]], on=["game_id", "team"], how="left")

# Drop rows with no box score (missing or zero minutes/points) or no derivable result.
keep = (df["min"].fillna(0) > 0) & df["pts"].notna() & df["result"].notna()
cols = ["game_id", "date", "season", "team", "opponent", "loc", "result", "player_id", "player",
        "min", "pts", "reb", "ast", "stl", "blk", "tov", "pf", "oreb", "dreb",
        "fgm", "fga", "fg3m", "fg3a", "ftm", "fta", "plus_minus"]
clean = df.loc[keep, cols].sort_values(["date", "game_id", "team", "player"])
clean["game_id"] = clean["game_id"].astype(str)

OUT.mkdir(exist_ok=True)
clean.to_csv(OUT / "player_games.csv", index=False)
info = {"raw_rows": int(len(raw)), "kept_rows": int(len(clean)), "dropped_rows": int(len(raw) - len(clean))}
(OUT / "build_info.json").write_text(json.dumps(info, indent=2))
print(info)
print("Seasons:", sorted(clean["season"].unique()), "| teams:", clean["team"].nunique(), "| players:", clean["player_id"].nunique())
